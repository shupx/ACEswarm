#!/usr/bin/env bash
set -euo pipefail
APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT="${1:-$APP_ROOT/artifacts}"
cd "$APP_ROOT/swarm_controlpad"
npm ci
npm run build
python3 "$APP_ROOT/scripts/build_package.py" --output "$OUTPUT"
