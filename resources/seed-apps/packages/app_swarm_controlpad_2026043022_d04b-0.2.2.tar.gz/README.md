# swarm_controlpad_pkg

`swarm_controlpad_pkg` 是一个符合 AivudaOS 规范的静态 UI app package，用于向多个 robot prefix 批量发送可配置的 zenoh `get` / `put` 请求。它支持独立运行，也支持作为 `panelhub` / `micro-panel-hub` 中的 `qiankun` 子应用嵌入。

## 目录结构

- `manifest.yaml`：标准 Aivuda app manifest
- `start.sh`：运行入口脚本，负责把 YAML 配置转成 `ui/app-config.js`
- `config/`：运行时配置，当前用于声明 `swarm_controlpad` 节点下的配置
- `assets/icon.svg`：应用图标
- `ui/`：前端构建产物，作为 `ui_index_path`
- `swarm_controlpad/`：前端源码目录，仅参与构建，不会打进最终 zip

## 主要功能

- 基于 `@eclipse-zenoh/zenoh-ts@1.7.2` 通过 websocket 发送 zenoh `get` / `put`
- 作为 `qiankun` 子应用时，优先从 `sharedState["swarm.selectedRobots"]` 读取目标 prefix
- 没有共享目标时，发送前弹窗要求手工输入多个 prefix
- 支持按钮、单行输入、多行输入、下拉发送和只读说明等 controlpad 组件
- 支持在 Settings 中编辑布局与 `get` / `put` 默认参数，并保存到浏览器 localStorage
- 页面底部固定显示反馈、结果和发送错误历史

## 前端构建

```bash
cd swarm_controlpad
pnpm install
pnpm build
```

构建完成后：

- 静态页面会输出到包根目录的 `ui/`
- `ui/` 中会包含 `index.html`、`app-config.js`、前端资源以及 `zenoh-ts` 依赖的 wasm 文件

## 打包

```bash
./pack.sh
./pack.sh /tmp/aivuda-packages
```

打包规则：

- zip 根目录直接包含 `manifest.yaml`
- 包含 `start.sh`、`scripts/`、`config/`、`assets/`、`ui/`
- 忽略 `.git/`
- 忽略 `swarm_controlpad/` 前端源码目录及其依赖

如果 `ui/index.html` 不存在，`pack.sh` 会先自动进入 `swarm_controlpad/` 执行前端构建。

## 配置项

`start.sh` 会把 app 配置转换成 `ui/app-config.js`，前端运行时从 `window.__SWARM_CONTROLPAD_CONFIG__` 读取这些值。

- `zenoh.plugins.remote_api.proxy_path`：当前页面 origin 后拼接的 websocket 反代路径，默认 `/zenoh_remote_api/ws`
- `swarm_controlpad.zenoh.websocket_locator`：可选显式 websocket locator，开发时留空会默认回退到 `ws://localhost:10000`
- `swarm_controlpad.controlpad_default_settings`：默认 controlpad 布局，内容应直接使用 Layout Editor 导出/复制的 `ControlpadLayout` JSON 对象

Controlpad layout 的生效优先级为：浏览器 localStorage 中保存的 `swarm_controlpad_settings` > `controlpad_default_settings` 注入的默认 layout > 前端内置 fallback layout。Layout Editor 顶栏的 `Reset to default` 会清除 localStorage 覆盖并恢复到运行时注入的默认 layout。

## 前端开发说明

[swarm_controlpad/README.md](swarm_controlpad/README.md)

## Standalone packaging

Clone this repository (with `--recurse-submodules` when it has submodules). Install Python 3.10+ and the pinned build dependencies with `python3 -m pip install -r requirements-pack.txt`. UI packages also require Node.js 22/npm; `pack.sh` runs `npm ci` from the committed lockfile and builds the UI. Run `./pack.sh` from any directory; output defaults to this repository’s `artifacts/`, or pass an output directory explicitly. All packaging tools are inside this repository. No sibling `integration` checkout or developer home path is required. System ROS/Docker runtime dependencies remain documented above.

The archive contains local runtime sources/assets, validates manifest paths and default configuration, excludes development/build caches, and rejects external symlinks. `SOURCE_DATE_EPOCH` controls archive timestamps (default 0).
