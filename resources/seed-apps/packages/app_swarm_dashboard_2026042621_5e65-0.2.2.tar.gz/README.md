# swarm_dashboard_pkg

`swarm_dashboard_pkg` 是一个符合 AivudaOS 规范的静态 UI app package，用于展示多个 robot 的 heartbeat 状态卡片。它通过 `zenoh-ts@1.7.2` 订阅 `*/heartbeat` 一类的 zenoh key，并支持独立运行或作为 `panelhub` / `micro-panel-hub` 中的 qiankun 子应用嵌入。

## 目录结构

- `manifest.yaml`：标准 Aivuda app manifest
- `start.sh`：运行入口脚本，作为静态 UI 包的轻量驻留进程
- `config/`：运行时配置，当前用于声明 `swarm_dashboard` 节点下的配置
- `assets/icon.svg`：应用图标
- `ui/`：前端构建产物，作为 `ui_index_path`
- `swarm_dashboard/`：前端源码目录，仅参与构建，不会打进最终 zip

## 主要功能

- 通过当前页面同源的 zenoh websocket 反代连接订阅 heartbeat
- 按 robot 维度生成 card，并显示 robot name
- card 支持多选，选中后以边框高亮
- robot name 支持点击后新标签页打开链接
- heartbeat 超时后将 robot 状态切换为 `disconnected`，但保留 card
- 支持通过页面空白处右键 `Settings` 配置 card 模板、附加 zenoh source、字段样式和状态规则
- 在 qiankun 场景下通过 `eventBus.emit("message", ...)` 向宿主发送：
  - 当前被选中的 robots
  - 当前探测到的在线 robots
- 在 qiankun 场景下通过 `sharedState` 发布 robot 列表：
  - `swarm.selectedRobots`：当前选中的 robots
  - `swarm.onlineRobots`：当前非 `disconnected` 的 robots
  - `swarm.dashboardRobots`：dashboard 当前维护的全量 robots，不按 status 或 selected 过滤

## 前端构建

```bash
cd swarm_dashboard
pnpm install
pnpm build
```

构建完成后：

- 静态页面会输出到包根目录的 `ui/`
- `ui/` 中会包含 `index.html`、`app-config.js`、前端资源以及 `zenoh-ts` 依赖的 wasm 文件

## 打包

```bash
./pack.sh
./pack.sh /tmp/aivuda-packages
```

打包规则：

- zip 根目录直接包含 `manifest.yaml`
- 包含 `start.sh`、`scripts/`、`config/`、`assets/`、`ui/`
- 忽略 `.git/`
- 忽略 `swarm_dashboard/` 前端源码目录及其依赖

如果 `ui/index.html` 不存在，`pack.sh` 会先自动进入 `swarm_dashboard/` 执行前端构建。

## 配置项

`start.sh` 会把 app 配置转换成 `ui/app-config.js`，前端运行时从 `window.__SWARM_DASHBOARD_CONFIG__` 读取这些值。若配置缺失或基础合法性检查失败，则会保留当前已有的 `ui/app-config.js` 并打印 warning。

- `swarm_dashboard.title`：页面标题
- `zenoh.plugins.remote_api.proxy_path`：当前页面 origin 后拼接的 websocket 反代路径，默认 `/zenoh_remote_api/ws`
- `swarm_dashboard.zenoh.key_expr`：订阅的 key expression，默认 `*/heartbeat`
- `swarm_dashboard.robot_link_template`：robot name 点击跳转模板，默认 `https://${avahi_hostname}.local:443`
- `swarm_dashboard.heartbeat_timeout_ms`：判定 heartbeat 超时断连的毫秒数，默认 `1700`
- `swarm_dashboard.card_default_settings`：默认 card settings，object 内容与 Card Settings 编辑器导出的 `{ templates, selection }` 完全一致，可直接粘贴导出结果进行持久化

默认配置会连接 `${window.location.origin}` 对应的 websocket 同源入口，并在其后追加 `/zenoh_remote_api/ws`，同时监听 `*/heartbeat`。

## Standalone packaging

Clone this repository (with `--recurse-submodules` when it has submodules). Install Python 3.10+ and the pinned build dependencies with `python3 -m pip install -r requirements-pack.txt`. UI packages also require Node.js 22/npm; `pack.sh` runs `npm ci` from the committed lockfile and builds the UI. Run `./pack.sh` from any directory; output defaults to this repository’s `artifacts/`, or pass an output directory explicitly. All packaging tools are inside this repository. No sibling `integration` checkout or developer home path is required. System ROS/Docker runtime dependencies remain documented above.

The archive contains local runtime sources/assets, validates manifest paths and default configuration, excludes development/build caches, and rejects external symlinks. `SOURCE_DATE_EPOCH` controls archive timestamps (default 0).
