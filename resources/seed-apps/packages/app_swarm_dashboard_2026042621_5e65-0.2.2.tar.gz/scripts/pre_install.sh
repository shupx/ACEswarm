#!/usr/bin/env bash
set -euo pipefail

echo "[pre_install.sh] no-op"
