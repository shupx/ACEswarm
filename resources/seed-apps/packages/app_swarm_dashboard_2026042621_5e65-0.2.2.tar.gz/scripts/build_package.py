#!/usr/bin/env python3
"""Validate and archive this repository without sibling workspace tools."""
import argparse
import gzip
import hashlib
import json
import os
import pathlib
import stat
import tarfile

import jsonschema
import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
EXCLUDED = {'.git', '.venv', 'venv', 'node_modules', 'build', 'install', 'log',
            '__pycache__', '.pytest_cache', '.vscode', '.idea', '.ros-deps',
            '.runtime', '.cache', 'artifacts', 'dist', 'tests'}
FRONTENDS = {'swarm_dashboard', 'swarm_controlpad', 'comm_status_viewer', 'foxglove_studio_panel'}


def local_file(value):
    path = ROOT / value
    if not path.resolve().is_relative_to(ROOT) or not path.is_file():
        raise ValueError(f'Missing or external package file: {value}')
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=pathlib.Path, default=ROOT / 'artifacts')
    args = parser.parse_args()
    output = args.output.resolve()
    manifest = yaml.safe_load(local_file('manifest.yaml').read_text())
    for field in ('default_config_path', 'config_schema_path', 'icon', 'ui_index_path',
                  'pre_install', 'pre_uninstall', 'update_this_version', 'caddyfile_config_path'):
        if manifest.get(field):
            local_file(manifest[field])
    entry = local_file(manifest['run']['entrypoint'])
    if not entry.stat().st_mode & stat.S_IXUSR:
        raise ValueError('Entrypoint must be executable')
    jsonschema.validate(yaml.safe_load(local_file(manifest['default_config_path']).read_text()),
                        yaml.safe_load(local_file(manifest['config_schema_path']).read_text()))
    if (ROOT / '.gitmodules').exists():
        import configparser
        modules = configparser.ConfigParser()
        modules.read(ROOT / '.gitmodules')
        for section in modules.sections():
            submodule = ROOT / modules[section]['path']
            if not submodule.is_dir() or not any(p.name != '.git' for p in submodule.iterdir()):
                raise ValueError('Missing submodule; run git submodule update --init --recursive')
    output.mkdir(parents=True, exist_ok=True)
    archive = output / (manifest['app_id'] + '-' + manifest['version'] + '.tar.gz')
    epoch = int(os.environ.get('SOURCE_DATE_EPOCH', '0'))
    with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=epoch) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for file in sorted(ROOT.rglob('*')):
                relative = file.relative_to(ROOT)
                if set(relative.parts) & (EXCLUDED | FRONTENDS) or file.is_dir():
                    continue
                if file.resolve().is_relative_to(output) or file.name.endswith(('.tar.gz', '.zip', '.tgz', '.tar', '.pyc', '.tsbuildinfo')):
                    continue
                if file.name in ('.gitmodules', '.gitignore'):
                    continue
                if not file.resolve().is_relative_to(ROOT):
                    raise ValueError(f'External symlink: {relative}')
                info = tar.gettarinfo(str(file), relative.as_posix())
                if info.issym() or info.islnk():
                    raise ValueError(f'Runtime symlink must be replaced by a local file: {relative}')
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = epoch
                info.mode = 0o755 if file.stat().st_mode & stat.S_IXUSR else 0o644
                with file.open('rb') as source:
                    tar.addfile(info, source)
    record = {'app_id': manifest['app_id'], 'version': manifest['version'], 'path': str(archive),
              'size': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
    (output / (archive.name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
