#!/usr/bin/env bash
set -euo pipefail

echo "[pre_uninstall.sh] no-op"
