#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UI_CONFIG_PATH="${SCRIPT_DIR}/ui/app-config.js"
WARN_YELLOW=$'\033[33m'
COLOR_RESET=$'\033[0m'

echo "[start.sh] started at $(date '+%Y-%m-%d %H:%M:%S')"
echo "[start.sh] app: ${AIVUDA_APP_ID:-swarm_dashboard}@${AIVUDA_APP_VERSION:-0.1.0}"

mkdir -p "$(dirname "${UI_CONFIG_PATH}")"

if python3 - "${AIVUDA_APP_CONFIG_PATH:-}" "${UI_CONFIG_PATH}" <<'PY'
import json
import sys
from pathlib import Path

import yaml

config_path = Path(sys.argv[1]) if sys.argv[1] else None
ui_config_path = Path(sys.argv[2])

if not config_path or not config_path.is_file():
    raise SystemExit("missing app config file, keeping existing ui config")

with config_path.open("r", encoding="utf-8") as fh:
    data = yaml.safe_load(fh) or {}

if not isinstance(data, dict):
    raise SystemExit("app config root must be a YAML object, keeping existing ui config")

zenoh_root = data.get("zenoh", {})
if not isinstance(zenoh_root, dict):
    raise SystemExit("missing or invalid zenoh config, keeping existing ui config")

swarm_dashboard = data.get("swarm_dashboard", {})
if not isinstance(swarm_dashboard, dict):
    raise SystemExit("missing or invalid swarm_dashboard config, keeping existing ui config")

plugins = zenoh_root.get("plugins", {})
if not isinstance(plugins, dict):
    plugins = {}

remote_api = plugins.get("remote_api", {})
if not isinstance(remote_api, dict):
    remote_api = {}

zenoh = swarm_dashboard.get("zenoh", {})
if not isinstance(zenoh, dict):
    raise SystemExit("missing or invalid swarm_dashboard.zenoh config, keeping existing ui config")

title = swarm_dashboard.get("title")
key_expr = zenoh.get("key_expr")
heartbeat_timeout_ms = swarm_dashboard.get("heartbeat_timeout_ms")
card_default_settings = swarm_dashboard.get("card_default_settings")

if not isinstance(title, str) or not title.strip():
    raise SystemExit("swarm_dashboard.title must be a non-empty string, keeping existing ui config")

proxy_path = remote_api.get("proxy_path")
if not isinstance(proxy_path, str) or not proxy_path.strip():
    raise SystemExit("zenoh.plugins.remote_api.proxy_path must be a non-empty string, keeping existing ui config")

if not isinstance(key_expr, str) or not key_expr.strip():
    raise SystemExit("swarm_dashboard.zenoh.key_expr must be a non-empty string, keeping existing ui config")

if not isinstance(heartbeat_timeout_ms, int) or heartbeat_timeout_ms <= 0:
    raise SystemExit("swarm_dashboard.heartbeat_timeout_ms must be a positive integer, keeping existing ui config")

if not isinstance(card_default_settings, dict):
    raise SystemExit("swarm_dashboard.card_default_settings must be an object, keeping existing ui config")

selection = card_default_settings.get("selection")
templates = card_default_settings.get("templates")
if not isinstance(selection, dict) or not isinstance(templates, dict):
    raise SystemExit("swarm_dashboard.card_default_settings must contain object selection/templates, keeping existing ui config")

payload = {
    "title": title.strip(),
    "zenoh": {
        "proxyPath": proxy_path.strip(),
        "keyExpr": key_expr.strip(),
    },
    "robotLinkTemplate": swarm_dashboard.get("robot_link_template", "https://${avahi_hostname}.local:443"),
    "heartbeatTimeoutMs": heartbeat_timeout_ms,
    "cardTemplateSelection": selection,
    "cardTemplates": templates,
}

ui_config_path.write_text(
    "window.__SWARM_DASHBOARD_CONFIG__ = "
    + json.dumps(payload, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
PY
then
  :
else
  echo "${WARN_YELLOW}[start.sh] warning: failed to refresh ui config; keeping existing ${UI_CONFIG_PATH}${COLOR_RESET}"
fi

echo "[start.sh] ui config: ${UI_CONFIG_PATH}"
echo "[start.sh] ui config content begin"
sed 's/^/[start.sh] ui config | /' "${UI_CONFIG_PATH}"
echo "[start.sh] ui config content end"
echo "[start.sh] static UI package is ready; no backend service will be started"

# Caddy serves assets on the host; only the managed idle process runs in Docker.
config_path="${AIVUDA_APP_CONFIG_PATH:-$SCRIPT_DIR/config/default_config.yaml}"
if [[ "$(python3 "$SCRIPT_DIR/scripts/config_get.py" "$config_path" swarm_dashboard.docker.enabled false)" == true ]]; then
  source "$SCRIPT_DIR/scripts/docker_helpers.sh"
  container="$(python3 "$SCRIPT_DIR/scripts/config_get.py" "$config_path" swarm_dashboard.docker.container '')"
  docker_helper_target_use_docker_container "$container"
  docker_helper_target_require_available '[start.sh]'
  exec python3 "$SCRIPT_DIR/scripts/process_runner.py" --container "$container" -- tail -f /dev/null
else
  exec tail -f /dev/null
fi
