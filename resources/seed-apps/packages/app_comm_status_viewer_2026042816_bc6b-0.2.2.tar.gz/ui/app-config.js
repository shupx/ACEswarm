window.__COMM_STATUS_VIEWER_CONFIG__ = {
  "title": "Comm Status Viewer",
  "zenoh": {
    "proxyPath": "/zenoh_remote_api/ws",
    "websocketLocator": "",
    "keyExpr": "*/comm_status"
  },
  "robotLinkTemplate": "https://${avahi_hostname}.local:443",
  "commStatusTimeoutMs": 1700,
  "defaultViewMode": "table"
};
