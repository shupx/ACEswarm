# panelhub_pkg

`panelhub_pkg` 是一个符合 AivudaOS 规范的静态 UI app package，使用 `@shupeixuan/micro-panel-hub`来实现qiankun加载子应用panels（子应用必须webpack构建，qiankun目前不兼容webpack构建的子应用），其包内前端源码目录名为 `panelhub/`。

## 目录结构

- `manifest.yaml`：标准 Aivuda app manifest
- `start.sh`：运行入口脚本，作为静态 UI 包的轻量驻留进程
- `config/`：运行时配置，当前用于声明 `panelhub` 节点下的配置
- `assets/icon.png`：应用图标
- `ui/`：前端构建产物，作为 `ui_index_path`
- `panelhub/`：前端源码目录，仅参与构建，不会打进最终 zip

## 前端构建

```bash
cd panelhub
pnpm install
pnpm build
```

构建完成后：

- 静态页面会输出到包根目录的 `ui/`
- `@shupeixuan/micro-panel-hub` 自带的 `popout.html` 会复制到 `ui/popout.html`
- `@shupeixuan/micro-panel-hub` 自带的 `sub-app-demo` 资源会复制到 `ui/sub-app-demo/`

开发时，`pnpm dev` 的 Vite dev server 也会直接挂载 `/popout.html` 和 `/sub-app-demo/`，方便本地验证浏览器弹窗和示例 panel。

如果想更新pnpm-lock.yaml里的@shupeixuan/micro-panel-hub dev版本：

```bash
cd panelhub
pnpm update @shupeixuan/micro-panel-hub
```

## 打包

```bash
./pack.sh
./pack.sh /tmp/aivuda-packages
```

打包规则：

- zip 根目录直接包含 `manifest.yaml`
- 包含 `start.sh`、`scripts/`、`config/`、`assets/`、`ui/`
- 忽略 `.git/`
- 忽略 `panelhub/` 前端源码目录及其依赖

## 配置项

- `panelhub.default_panels`：追加到 `Add` 菜单的预置 panel 列表
- `panelhub.default_layout`：配置 `MicroPanelHub` 初始布局，仅在当前浏览器没有已保存布局时生效
- `panelhub.title_link`：配置 `MicroPanelHub` 标题链接

默认包配置会生成一个 `sub-app-demo` 预置 panel，指向 `/sub-app-demo/`。
默认布局会作为 `initialLayout` 传入 `MicroPanelHub`；如果浏览器 localStorage 里已经有 `aivuda_panelhub_layout`，已保存布局会优先生效。

## panelhub前端开发

[panelhub/README.md](panelhub/README.md)
