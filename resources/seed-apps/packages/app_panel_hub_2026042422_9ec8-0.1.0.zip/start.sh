#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UI_CONFIG_PATH="${SCRIPT_DIR}/ui/app-config.js"

echo "[start.sh] started at $(date '+%Y-%m-%d %H:%M:%S')"
echo "[start.sh] app: ${AIVUDA_APP_ID:-panelhub}@${AIVUDA_APP_VERSION:-0.1.0}"

mkdir -p "$(dirname "${UI_CONFIG_PATH}")"

python3 - "${AIVUDA_APP_CONFIG_PATH:-}" "${UI_CONFIG_PATH}" <<'PY'
import json
import sys
from pathlib import Path

import yaml

config_path = Path(sys.argv[1]) if sys.argv[1] else None
ui_config_path = Path(sys.argv[2])

DEFAULT_TITLE_LINK = "https://github.com/shupx/micro-panel-hub"
default_panels = []
default_layout = None
title_link = DEFAULT_TITLE_LINK

if config_path and config_path.is_file():
    with config_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    panelhub_config = data.get("panelhub", {})
    if not isinstance(panelhub_config, dict):
        panelhub_config = {}

    loaded_panels = panelhub_config.get("default_panels", [])
    if isinstance(loaded_panels, list):
        default_panels = loaded_panels

    loaded_title_link = panelhub_config.get("title_link")
    if isinstance(loaded_title_link, str) and loaded_title_link.strip():
        title_link = loaded_title_link.strip()

    loaded_layout = panelhub_config.get("default_layout")
    if isinstance(loaded_layout, dict):
        default_layout = loaded_layout

payload = {
    "defaultPanels": default_panels,
    "defaultLayout": default_layout,
    "titleLink": title_link,
}

ui_config_path.write_text(
    "window.__PANELHUB_CONFIG__ = "
    + json.dumps(payload, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
PY

echo "[start.sh] ui config: ${UI_CONFIG_PATH}"
echo "[start.sh] ui config content begin"
sed 's/^/[start.sh] ui config | /' "${UI_CONFIG_PATH}"
echo "[start.sh] ui config content end"
echo "[start.sh] static UI package is ready; no backend service will be started"

exec tail -f /dev/null
