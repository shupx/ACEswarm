window.__PANELHUB_CONFIG__ = {
  titleLink: "https://github.com/shupx/micro-panel-hub",
  defaultPanels: [
    {
      name: "sub-app-demo",
      source: {
        type: "page-relative-route",
        value: "/sub-app-demo/",
      },
    },
  ],
  defaultLayout: {
    version: 2,
    topBarCollapsed: false,
    activeTopTabId: "tab-1",
    tabs: [
      {
        id: "tab-1",
        title: "Tab 1",
        layout: {
          global: {
            splitterSize: 3,
            splitterExtra: 4,
            tabEnablePopout: true,
          },
          borders: [],
          layout: {
            type: "row",
            id: "main-row",
            children: [
              {
                type: "tabset",
                id: "#bd46975d-bd7b-4640-a707-2a89f0a941a1",
                weight: 23.522791221159256,
                enableTabStrip: false,
                children: [
                  {
                    type: "tab",
                    id: "#5934bd98-67d4-4ae9-8a20-f2be5a516b77",
                    name: "Swarm Dashboard",
                    component: "sub-app",
                    config: {
                      name: "Swarm Dashboard",
                      source: {
                        type: "site-relative-route",
                        value: "/app_swarm_dashboard_2026042621_5e65/ui/",
                      },
                      entry:
                        "http://127.0.0.1/app_swarm_dashboard_2026042621_5e65/ui/",
                    },
                  },
                ],
              },
              {
                type: "row",
                id: "#926aac06-4928-4ed1-9004-3dfca1384afd",
                weight: 76.47720877884075,
                children: [
                  {
                    type: "tabset",
                    id: "#5153261a-2cee-4cf2-a3b2-61fafd89d68a",
                    weight: 81.64313222079589,
                    enableTabStrip: false,
                    children: [
                      {
                        type: "tab",
                        id: "#a24a66f9-f5d1-4ea1-81c7-ba507ae32e79",
                        name: "Foxglove Studio Embed",
                        component: "sub-app",
                        config: {
                          name: "Foxglove Studio Embed",
                          source: {
                            type: "site-relative-route",
                            value:
                              "/app_foxglove_studio_embed_2026042417_a909/ui/",
                          },
                          entry:
                            "http://127.0.0.1/app_foxglove_studio_embed_2026042417_a909/ui/",
                        },
                      },
                    ],
                  },
                  {
                    type: "row",
                    id: "#ca7f4a3e-4bfe-4a89-a2ef-b0eee994ca46",
                    weight: 18.35686777920411,
                    children: [
                      {
                        type: "tabset",
                        id: "#2d4f5876-d30c-4c32-8f3c-86043922997b",
                        weight: 55.85636397819139,
                        enableTabStrip: false,
                        children: [
                          {
                            type: "tab",
                            id: "#ccacb283-bb06-46a6-94cc-c91db0eae622",
                            name: "Swarm Controlpad",
                            component: "sub-app",
                            config: {
                              name: "Swarm Controlpad",
                              source: {
                                type: "site-relative-route",
                                value:
                                  "/app_swarm_controlpad_2026043022_d04b/ui/",
                              },
                              entry:
                                "http://127.0.0.1/app_swarm_controlpad_2026043022_d04b/ui/",
                            },
                          },
                        ],
                        active: true,
                      },
                      {
                        type: "tabset",
                        id: "#46566fa9-455b-4756-83c6-abc510376d8b",
                        weight: 44.14363602180861,
                        enableTabStrip: false,
                        children: [
                          {
                            type: "tab",
                            id: "#54795cc6-05b2-40bd-b531-95d24ef718f7",
                            name: "Comm Status Viewer",
                            component: "sub-app",
                            config: {
                              name: "Comm Status Viewer",
                              source: {
                                type: "site-relative-route",
                                value:
                                  "/app_comm_status_viewer_2026042816_bc6b/ui/",
                              },
                              entry:
                                "http://127.0.0.1/app_comm_status_viewer_2026042816_bc6b/ui/",
                            },
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          popouts: {},
        },
      },
    ],
  },
};
