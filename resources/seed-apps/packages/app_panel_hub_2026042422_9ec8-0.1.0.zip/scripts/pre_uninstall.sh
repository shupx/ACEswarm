#!/usr/bin/env bash
set -euo pipefail

echo "[pre_uninstall] panelhub_pkg has no uninstall actions"
