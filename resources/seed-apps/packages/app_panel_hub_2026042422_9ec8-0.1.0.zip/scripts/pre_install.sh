#!/usr/bin/env bash
set -euo pipefail

echo "[pre_install] panelhub_pkg has no system dependencies"
