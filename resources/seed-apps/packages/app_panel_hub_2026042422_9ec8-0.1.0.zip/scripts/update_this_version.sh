#!/usr/bin/env bash
set -euo pipefail

echo "[update_this_version] no in-place update actions defined for panelhub_pkg"
