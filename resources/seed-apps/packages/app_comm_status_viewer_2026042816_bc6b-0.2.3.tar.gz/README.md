# comm_status_viewer_pkg

`comm_status_viewer_pkg` 是一个符合 AivudaOS 规范的静态 UI app package，用于展示多个 robot 之间的通信连通关系。它通过 `zenoh-ts@1.7.2` 订阅 `*/comm_status` 一类的 zenoh key，并支持独立运行或作为 `panelhub` / `micro-panel-hub` 中的 qiankun 子应用嵌入。

## 目录结构

- `manifest.yaml`：标准 Aivuda app manifest
- `start.sh`：运行入口脚本，作为静态 UI 包的轻量驻留进程
- `config/`：运行时配置，当前用于声明 `comm_status_viewer` 节点下的配置
- `assets/icon.svg`：应用图标
- `ui/`：前端构建产物，作为 `ui_index_path`
- `comm_status_viewer/`：前端源码目录，仅参与构建，不会打进最终 zip

## 主要功能

- 通过当前页面同源的 zenoh websocket 反代连接订阅 `comm_status`
- 按 `key_prefix` 维度构建 robot 集合，并合并 `self` / `connected_neighbors` 元数据
- 提供可切换的矩阵表格视图与有向拓扑图视图
- 点击 robot label 后按 `robot_link_template` 打开对应 AivudaOS 页面
- 对 stale report 做超时处理，但仍保留 robot 在画面上的展示

## 前端构建

```bash
cd comm_status_viewer
pnpm install
pnpm build
```

构建完成后：

- 静态页面会输出到包根目录的 `ui/`
- `ui/` 中会包含 `index.html`、`app-config.js`、前端资源以及 `zenoh-ts` 依赖的 wasm 文件

## 打包

```bash
./pack.sh
./pack.sh /tmp/aivuda-packages
```

打包规则：

- zip 根目录直接包含 `manifest.yaml`
- 包含 `start.sh`、`scripts/`、`config/`、`assets/`、`ui/`
- 忽略 `.git/`
- 忽略 `comm_status_viewer/` 前端源码目录及其依赖

如果 `ui/index.html` 不存在，`pack.sh` 会先自动进入 `comm_status_viewer/` 执行前端构建。

## 配置项

`start.sh` 会把 app 配置转换成 `ui/app-config.js`，前端运行时从 `window.__COMM_STATUS_VIEWER_CONFIG__` 读取这些值。

- `comm_status_viewer.title`：页面标题
- `zenoh.plugins.remote_api.proxy_path`：当前页面 origin 后拼接的 websocket 反代路径，默认 `/zenoh_remote_api/ws`
- `comm_status_viewer.zenoh.key_expr`：订阅的 key expression，默认 `*/comm_status`
- `comm_status_viewer.zenoh.websocket_locator`：可选显式 websocket locator，开发时留空会默认回退到 `ws://localhost:10000`
- `comm_status_viewer.robot_link_template`：robot name 点击跳转模板，默认 `https://${avahi_hostname}.local:443`
- `comm_status_viewer.comm_status_timeout_ms`：判定 report stale 的毫秒数，默认 `2500`
- `comm_status_viewer.default_view_mode`：默认视图模式，支持 `table` / `graph`

## Standalone packaging

Clone this repository (with `--recurse-submodules` when it has submodules). Install Python 3.10+ and the pinned build dependencies with `python3 -m pip install -r requirements-pack.txt`. UI packages also require Node.js 22/npm; `pack.sh` runs `npm ci` from the committed lockfile and builds the UI. Run `./pack.sh` from any directory; output defaults to this repository’s `artifacts/`, or pass an output directory explicitly. All packaging tools are inside this repository. No sibling `integration` checkout or developer home path is required. System ROS/Docker runtime dependencies remain documented above.

The archive contains local runtime sources/assets, validates manifest paths and default configuration, excludes development/build caches, and rejects external symlinks. `SOURCE_DATE_EPOCH` controls archive timestamps (default 0).
