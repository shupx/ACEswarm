#!/usr/bin/env python3
"""Read a scalar Aivuda YAML configuration value without evaluating it."""
import sys
from pathlib import Path

try:
    import yaml
except ImportError as exc:
    raise SystemExit("PyYAML is required (install python3-yaml)") from exc

if len(sys.argv) != 4:
    raise SystemExit("usage: config_get.py CONFIG_PATH dotted.key fallback")

config_path, dotted_key, fallback = sys.argv[1:]
try:
    value = yaml.safe_load(Path(config_path).read_text(encoding="utf-8")) or {}
except FileNotFoundError:
    raise SystemExit(f"configuration file not found: {config_path}")
except yaml.YAMLError as exc:
    raise SystemExit(f"invalid YAML configuration {config_path}: {exc}")

for part in dotted_key.split("."):
    if not isinstance(value, dict) or part not in value:
        value = fallback
        break
    value = value[part]
if value is None:
    value = ""
elif value is True:
    value = "true"
elif value is False:
    value = "false"
elif isinstance(value, (dict, list)):
    raise SystemExit(f"configuration value must be scalar: {dotted_key}")
print(value)
