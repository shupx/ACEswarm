#!/usr/bin/env bash
set -e

echo "[pre_install.sh] no-op"
