#!/usr/bin/env python3
"""Foreground host/Docker supervisor with bounded, app-scoped group cleanup."""
import argparse,os,pathlib,re,shlex,signal,subprocess,sys,time,uuid
p=argparse.ArgumentParser(); p.add_argument('--container'); p.add_argument('--script'); p.add_argument('--env-prefix',action='append',default=[]); p.add_argument('command',nargs=argparse.REMAINDER); args=p.parse_args()
container=args.container
runid=uuid.uuid4().hex; remote_dir='/tmp/aivuda-managed-process/'+runid
command=args.command
if command[:1]==['--']:command=command[1:]
if args.script: command=['bash',args.script]
if not command: p.error('script or command is required')
if container:
 if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*',container): raise ValueError('Invalid Docker container name')
 if subprocess.check_output(['docker','inspect','-f','{{.State.Running}}',container],text=True).strip()!='true': raise ValueError('Docker target must already be running')
 subprocess.run(['docker','exec',container,'mkdir','-p',remote_dir],check=True)
 if args.script:
  if subprocess.run(['docker','exec',container,'test','-f',args.script]).returncode==0:
   command=['bash',args.script]
  else:
   subprocess.run(['docker','cp',str(pathlib.Path(args.script).parent)+'/.',container+':'+remote_dir+'/'],check=True)
   command=['bash',remote_dir+'/'+pathlib.Path(args.script).name]
 forward=[]
 for key,value in os.environ.items():
  if key in ['ROS_DOMAIN_ID','ROS_LOCALHOST_ONLY','RMW_IMPLEMENTATION','DISPLAY','CUDA_VISIBLE_DEVICES'] or any(key.startswith(prefix) for prefix in args.env_prefix): forward+=['-e',key+'='+value]
 wrapper='echo $$ > "$1/pid"; shift; exec "$@"'
 argv=['docker','exec','-i',*forward,container,'setsid','--wait','bash','-c',wrapper,'--',remote_dir,*command]
else: argv=command
proc=subprocess.Popen(argv,start_new_session=True)
stopping=False
def stop(*_):
 global stopping
 if stopping:return
 stopping=True
 if container:
  # Unique run directory identifies only this workload; container stays running.
  script='if [[ -f "$1/pid" ]]; then p=$(cat "$1/pid"); kill -TERM -- -"$p" 2>/dev/null || true; for i in {1..100}; do kill -0 -- -"$p" 2>/dev/null || exit 0; sleep .1; done; kill -KILL -- -"$p" 2>/dev/null || true; fi'
  try: subprocess.run(['docker','exec',container,'bash','-c',script,'--',remote_dir],timeout=13)
  except subprocess.TimeoutExpired: pass
 else:
  try: os.killpg(proc.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 try: proc.wait(timeout=12)
 except subprocess.TimeoutExpired:
  try: os.killpg(proc.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  proc.wait()
 # Children can outlive the launcher; kill its owned process group as well.
 if not container:
  try: os.killpg(proc.pid,signal.SIGKILL)
  except ProcessLookupError:pass
stop_requested=False
def request_stop(*_):
 global stop_requested
 stop_requested=True
signal.signal(signal.SIGTERM,request_stop); signal.signal(signal.SIGINT,request_stop)
try:
 while proc.poll() is None:
  if stop_requested:
   stop()
   break
  time.sleep(.05)
 code=proc.returncode
finally:
 stop()
 if container:subprocess.run(['docker','exec',container,'rm','-rf',remote_dir],timeout=10)
sys.exit(code if code>=0 else 128-code)
