#!/usr/bin/env bash
set -e

echo "[pre_uninstall.sh] no-op"
