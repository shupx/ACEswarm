#!/usr/bin/env bash
set -e

if [[ $# -ne 1 ]]; then
  echo "usage: $0 <version>" >&2
  exit 1
fi

version="$1"
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
pkg_dir="$(cd "${script_dir}/.." && pwd)"
manifest_path="${pkg_dir}/manifest.yaml"
package_json_path="${pkg_dir}/swarm_controlpad/package.json"

python3 - "$manifest_path" "$version" <<'PY'
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
version = sys.argv[2]
text = path.read_text(encoding="utf-8")
text, count = re.subn(r"^version:\s*.+$", f"version: {version}", text, flags=re.MULTILINE)
if count != 1:
    raise SystemExit("failed to update manifest version")
path.write_text(text, encoding="utf-8")
PY

python3 - "$package_json_path" "$version" <<'PY'
from pathlib import Path
import json
import sys

path = Path(sys.argv[1])
version = sys.argv[2]
data = json.loads(path.read_text(encoding="utf-8"))
data["version"] = version
path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY

echo "[update_this_version.sh] updated version to ${version}"
