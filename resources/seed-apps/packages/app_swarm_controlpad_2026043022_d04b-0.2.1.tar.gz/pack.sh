#!/usr/bin/env bash
set -euo pipefail
APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT="${1:-$(dirname "$APP_ROOT")/artifacts}"
cd "$APP_ROOT/swarm_controlpad"
[[ -d node_modules ]] || npm ci
npm run build
python3 "$APP_ROOT/../integration/build_packages.py" "$(basename "$APP_ROOT")" --output "$OUTPUT"
