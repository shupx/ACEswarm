#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UI_CONFIG_PATH="${SCRIPT_DIR}/ui/app-config.js"

echo "[start.sh] started at $(date '+%Y-%m-%d %H:%M:%S')"
echo "[start.sh] app: ${AIVUDA_APP_ID:-comm_status_viewer}@${AIVUDA_APP_VERSION:-0.1.0}"

mkdir -p "$(dirname "${UI_CONFIG_PATH}")"

python3 - "${AIVUDA_APP_CONFIG_PATH:-}" "${UI_CONFIG_PATH}" <<'PY'
import json
import sys
from pathlib import Path

import yaml

config_path = Path(sys.argv[1]) if sys.argv[1] else None
ui_config_path = Path(sys.argv[2])

payload = {
    "title": "Comm Status Viewer",
    "zenoh": {
        "proxyPath": "/zenoh_remote_api/ws",
        "websocketLocator": "",
        "keyExpr": "*/comm_status",
    },
    "robotLinkTemplate": "https://${avahi_hostname}.local:443",
    "commStatusTimeoutMs": 2500,
    "defaultViewMode": "table",
}

if config_path and config_path.is_file():
    with config_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    zenoh_root = data.get("zenoh", {})
    if not isinstance(zenoh_root, dict):
        zenoh_root = {}

    comm_status_viewer = data.get("comm_status_viewer", {})
    if not isinstance(comm_status_viewer, dict):
        comm_status_viewer = {}

    title = comm_status_viewer.get("title")
    if isinstance(title, str) and title.strip():
        payload["title"] = title.strip()

    plugins = zenoh_root.get("plugins", {})
    if not isinstance(plugins, dict):
        plugins = {}

    remote_api = plugins.get("remote_api", {})
    if not isinstance(remote_api, dict):
        remote_api = {}

    proxy_path = remote_api.get("proxy_path")
    if isinstance(proxy_path, str) and proxy_path.strip():
        payload["zenoh"]["proxyPath"] = proxy_path.strip()

    zenoh = comm_status_viewer.get("zenoh", {})
    if not isinstance(zenoh, dict):
        zenoh = {}

    websocket_locator = zenoh.get("websocket_locator")
    if isinstance(websocket_locator, str):
        payload["zenoh"]["websocketLocator"] = websocket_locator

    key_expr = zenoh.get("key_expr")
    if isinstance(key_expr, str) and key_expr.strip():
        payload["zenoh"]["keyExpr"] = key_expr.strip()

    robot_link_template = comm_status_viewer.get("robot_link_template")
    if isinstance(robot_link_template, str):
        payload["robotLinkTemplate"] = robot_link_template

    comm_status_timeout_ms = comm_status_viewer.get("comm_status_timeout_ms")
    if isinstance(comm_status_timeout_ms, int) and comm_status_timeout_ms > 0:
        payload["commStatusTimeoutMs"] = comm_status_timeout_ms

    default_view_mode = comm_status_viewer.get("default_view_mode")
    if default_view_mode in {"table", "graph"}:
        payload["defaultViewMode"] = default_view_mode

ui_config_path.write_text(
    "window.__COMM_STATUS_VIEWER_CONFIG__ = "
    + json.dumps(payload, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
PY

echo "[start.sh] ui config: ${UI_CONFIG_PATH}"
echo "[start.sh] ui config content begin"
sed 's/^/[start.sh] ui config | /' "${UI_CONFIG_PATH}"
echo "[start.sh] ui config content end"
echo "[start.sh] static UI package is ready; no backend service will be started"

# Caddy serves assets on the host; only the managed idle process runs in Docker.
config_path="${AIVUDA_APP_CONFIG_PATH:-$SCRIPT_DIR/config/default_config.yaml}"
if [[ "$(python3 "$SCRIPT_DIR/scripts/config_get.py" "$config_path" comm_status_viewer.docker.enabled false)" == true ]]; then
  source "$SCRIPT_DIR/scripts/docker_helpers.sh"
  container="$(python3 "$SCRIPT_DIR/scripts/config_get.py" "$config_path" comm_status_viewer.docker.container '')"
  docker_helper_target_use_docker_container "$container"
  docker_helper_target_require_available '[start.sh]'
  exec python3 "$SCRIPT_DIR/scripts/process_runner.py" --container "$container" -- tail -f /dev/null
else
  exec tail -f /dev/null
fi
