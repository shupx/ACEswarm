#!/usr/bin/env bash
set -euo pipefail
APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "${1:-$APP_ROOT/artifacts}"
OUTPUT="$(cd "${1:-$APP_ROOT/artifacts}" && pwd)"
cd "$APP_ROOT"
# These manifest fields are plain, single-line package identifiers.
APP_ID="$(sed -n 's/^app_id: *//p' manifest.yaml)"
VERSION="$(sed -n 's/^version: *//p' manifest.yaml)"
[[ "$APP_ID" =~ ^[A-Za-z0-9_.-]+$ && "$VERSION" =~ ^[A-Za-z0-9_.-]+$ ]]

(cd "comm_status_viewer" && npm ci && npm run build)

# ROS source packages are built by pre_install in the selected host/container.
# System-package wrappers require no workspace or compilation.
ARCHIVE="$OUTPUT/$APP_ID-$VERSION.tar.gz"
tar --exclude-vcs --exclude='.gitmodules' \
  --exclude='node_modules' --exclude='build' --exclude='devel' \
  --exclude='install' --exclude='log' --exclude='dist' \
  --exclude='__pycache__' --exclude='*.pyc' --exclude='*.tsbuildinfo' \
  --exclude='.venv' --exclude='venv' --exclude='.pytest_cache' \
  --exclude='.vscode' --exclude='.idea' --exclude='.ros-deps' \
  --exclude='.runtime' --exclude='.cache' --exclude='artifacts' \
  --exclude='tests' --exclude='*.tar.gz' --exclude='*.tgz' --exclude='*.zip' \
  --exclude='./comm_status_viewer' \
  --exclude="${OUTPUT#"$APP_ROOT/"}" \
  --transform='s,^\./,,' -czf "$ARCHIVE" .
printf '%s\n' "$ARCHIVE"
