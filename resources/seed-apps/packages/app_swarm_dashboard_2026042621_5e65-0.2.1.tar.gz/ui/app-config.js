window.__SWARM_DASHBOARD_CONFIG__ = {
  "title": "Swarm Dashboard",
  "zenoh": {
    "proxyPath": "/zenoh_remote_api/ws",
    "keyExpr": "*/heartbeat"
  },
  "robotLinkTemplate": "https://${avahi_hostname}.local:443",
  "heartbeatTimeoutMs": 1700,
  "cardTemplateSelection": {
    "manualTemplateKey": "default",
    "mode": "auto"
  },
  "cardTemplates": {
    "default": {
      "gridCols": 24,
      "gridRowHeight": 2,
      "sources": [],
      "statusRules": [],
      "widgets": [
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 14,
          "id": "widget_robot_type",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "robot type",
          "layout": {
            "h": 6,
            "w": 24,
            "x": 0,
            "y": 0
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [],
          "tip": "",
          "value": {
            "fallbackText": "--",
            "template": "{{heartbeat.robot_type}}"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 14,
          "id": "widget_key",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "key",
          "layout": {
            "h": 5,
            "w": 24,
            "x": 0,
            "y": 6
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [],
          "tip": "",
          "value": {
            "fallbackText": "--",
            "template": "{{robot.key}}"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 12,
          "id": "widget_last_heartbeat",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "last heartbeat",
          "layout": {
            "h": 9,
            "w": 24,
            "x": 0,
            "y": 11
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [],
          "tip": "",
          "value": {
            "fallbackText": "--",
            "template": "{{datetime(heartbeat.timestamp_unix_ms, \"ms\", \"YYYY-MM-DD HH:mm:ss:SSS\")}}"
          },
          "valueAlign": "justify"
        }
      ]
    },
    "mocap_rotor": {
      "gridCols": 24,
      "gridRowHeight": 2,
      "sources": [
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_local_pos",
          "keyExprTemplate": "*/telemetry/local_pos",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_state",
          "keyExprTemplate": "*/telemetry/state",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_imu",
          "keyExprTemplate": "*/telemetry/imu",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_gps",
          "keyExprTemplate": "*/telemetry/gps",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_setpoint",
          "keyExprTemplate": "*/telemetry/setpoint",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_battery",
          "keyExprTemplate": "*/telemetry/battery",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_telemetry_vision_pose",
          "keyExprTemplate": "*/telemetry/vision_pose",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_mavros_basic_motion_status",
          "keyExprTemplate": "*/mavros_basic_motion/status",
          "payloadFormat": "json"
        },
        {
          "freshnessMs": 3000,
          "id": "source_mavros_setpoint_mux_status",
          "keyExprTemplate": "*/mavros_setpoint_mux/status",
          "payloadFormat": "json"
        }
      ],
      "statusRules": [],
      "widgets": [
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "no mode",
          "fontSize": 12,
          "id": "widget_1778075712941_3n271",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "",
          "layout": {
            "h": 7,
            "w": 9,
            "x": 0,
            "y": 18
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-ok)",
              "when": {
                "op": "eq",
                "path": "data.mode",
                "sourceRef": "source_telemetry_state",
                "value": "OFFBOARD"
              }
            }
          ],
          "tip": "mode",
          "value": {
            "fallbackText": "no mode",
            "template": "{{source_telemetry_state.data.mode}}"
          },
          "valueAlign": "center"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 12,
          "id": "widget_1778076848299_gkl54",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "",
          "layout": {
            "h": 7,
            "w": 7,
            "x": 9,
            "y": 18
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-ok)",
              "when": {
                "op": "eq",
                "path": "data.armed",
                "sourceRef": "source_telemetry_state",
                "value": true
              }
            }
          ],
          "tip": "arming state",
          "value": {
            "fallbackText": "--",
            "template": "{{if(eq(source_telemetry_state.data.armed, true), \"armed\", \"disarmed\")}}"
          },
          "valueAlign": "center"
        },
        {
          "borderColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778078477550_h2q4w",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "IMU",
          "layout": {
            "h": 8,
            "w": 4,
            "x": 20,
            "y": 17
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "lt",
                "path": "sources.imu.measured_hz",
                "sourceRef": "source_telemetry_imu",
                "value": 29
              }
            }
          ],
          "tip": "imu",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(source_telemetry_imu.sources.imu.measured_hz,0)}}Hz"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778079002280_135ja",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "",
          "layout": {
            "h": 9,
            "w": 4,
            "x": 20,
            "y": 26
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [
            {
              "emphasis": "normal",
              "when": {
                "op": "gt",
                "path": "sources.pose.measured_hz",
                "sourceRef": "source_telemetry_local_pos",
                "value": 0
              }
            },
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "lt",
                "path": "sources.pose.measured_hz",
                "sourceRef": "source_telemetry_local_pos",
                "value": 25
              }
            },
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-error)",
              "when": {
                "op": "lt",
                "path": "sources.pose.measured_hz",
                "sourceRef": "source_telemetry_local_pos",
                "value": 2
              }
            },
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-error)",
              "when": {
                "op": "not_exists",
                "path": "",
                "sourceRef": "source_telemetry_local_pos",
                "value": ""
              }
            }
          ],
          "tip": "local_position/pose",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(source_telemetry_local_pos.sources.pose.measured_hz,0)}}Hz"
          },
          "valueAlign": "left"
        },
        {
          "borderColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778080673317_ahnu0",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "Glo",
          "layout": {
            "h": 8,
            "w": 4,
            "x": 16,
            "y": 17
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [],
          "tip": "global_position/global",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(source_telemetry_gps.sources.global.measured_hz, 0)}}Hz"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778080922504_u4lmn",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "",
          "layout": {
            "h": 9,
            "w": 4,
            "x": 20,
            "y": 35
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-ok)",
              "when": {
                "op": "gte",
                "path": "sources.local.measured_hz",
                "sourceRef": "source_telemetry_setpoint",
                "value": 3
              }
            }
          ],
          "tip": "setpoint_raw/local",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(source_telemetry_setpoint.sources.local.measured_hz, 0)}}Hz"
          },
          "valueAlign": "center"
        },
        {
          "borderColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778081401145_0gvo6",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "cur",
          "layout": {
            "h": 8,
            "w": 4,
            "x": 20,
            "y": 8
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [],
          "tip": "discharge current",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(mul(source_telemetry_battery.data.current, -1), 1)}}A"
          },
          "valueAlign": "left"
        },
        {
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 12,
          "id": "widget_1778131972001_fk7ya",
          "inlineLabelValue": false,
          "kind": "battery_icon",
          "label": "",
          "layout": {
            "h": 6,
            "w": 6,
            "x": 17,
            "y": 1
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": true,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-ok-bg)",
              "when": {
                "op": "lt",
                "path": "data.percentage",
                "sourceRef": "source_telemetry_battery",
                "value": 1.1
              }
            },
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "lt",
                "path": "data.percentage",
                "sourceRef": "source_telemetry_battery",
                "value": 0.2
              }
            },
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-error)",
              "when": {
                "op": "lt",
                "path": "data.percentage",
                "sourceRef": "source_telemetry_battery",
                "value": 0.1
              }
            }
          ],
          "tip": "battery percentage",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(mul(source_telemetry_battery.data.percentage, 100), 1)}}"
          },
          "valueAlign": "left"
        },
        {
          "borderColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778132995463_9itw0",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "volt",
          "layout": {
            "h": 8,
            "w": 4,
            "x": 16,
            "y": 8
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": false,
          "styleRules": [],
          "tip": "voltage",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(source_telemetry_battery.data.voltage, 1)}}V"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778134960658_d9nbu",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "",
          "layout": {
            "h": 5,
            "w": 4,
            "x": 20,
            "y": 44
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": false,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "not_exists",
                "path": "",
                "sourceRef": "source_telemetry_vision_pose",
                "value": ""
              }
            }
          ],
          "tip": "vision_pose/pose",
          "value": {
            "fallbackText": "--",
            "template": "{{fixed(source_telemetry_vision_pose.sources.vision_pose.measured_hz, 0)}}Hz"
          },
          "valueAlign": "left"
        },
        {
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 12,
          "id": "widget_1778135385675_b716t",
          "inlineLabelValue": false,
          "kind": "flight_indicator",
          "label": "",
          "layout": {
            "h": 17,
            "w": 16,
            "x": 0,
            "y": 0
          },
          "showAttitude": true,
          "showCompass": true,
          "showValueInside": false,
          "styleRules": [],
          "tip": "",
          "value": {
            "fallbackText": "--",
            "template": "{{source_telemetry_local_pos.data.orientation}}"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778141471423_f6pcz",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "local pose",
          "layout": {
            "h": 9,
            "w": 20,
            "x": 0,
            "y": 26
          },
          "showAttitude": false,
          "showCompass": false,
          "showValueInside": false,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-error)",
              "when": {
                "op": "not_exists",
                "path": "",
                "sourceRef": "source_telemetry_local_pos",
                "value": ""
              }
            }
          ],
          "tip": "local_position/pose",
          "value": {
            "fallbackText": "--",
            "template": "p: ({{default(fixed(source_telemetry_local_pos.data.position.x, 1), \"--\")}}, {{default(fixed(source_telemetry_local_pos.data.position.y, 1), \"--\")}}, {{default(fixed(source_telemetry_local_pos.data.position.z, 1), \"--\")}})\nv: ({{default(fixed(source_telemetry_local_pos.data.linear_velocity.x, 1), \"--\")}}, {{default(fixed(source_telemetry_local_pos.data.linear_velocity.y, 1), \"--\")}}, {{default(fixed(source_telemetry_local_pos.data.linear_velocity.z, 1), \"--\")}})"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 12,
          "id": "widget_1778141643466_nu9ra",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "vision pose",
          "layout": {
            "h": 5,
            "w": 20,
            "x": 0,
            "y": 44
          },
          "showAttitude": false,
          "showCompass": false,
          "showValueInside": false,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "not_exists",
                "path": "",
                "sourceRef": "source_telemetry_vision_pose",
                "value": ""
              }
            }
          ],
          "tip": "vision_pose/pose",
          "value": {
            "fallbackText": "--",
            "template": "{{default(fixed(source_telemetry_vision_pose.data.position.x, 1), \"--\")}}, {{default(fixed(source_telemetry_vision_pose.data.position.y, 1), \"--\")}}, {{default(fixed(source_telemetry_vision_pose.data.position.z, 1), \"--\")}}"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 12,
          "id": "widget_1778142133102_f7m7a",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "motion action",
          "layout": {
            "h": 9,
            "w": 12,
            "x": 0,
            "y": 54
          },
          "showAttitude": false,
          "showCompass": false,
          "showValueInside": false,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "ne",
                "path": "status.active_action",
                "sourceRef": "source_mavros_basic_motion_status",
                "value": ""
              }
            }
          ],
          "tip": "mavros_basic_motion active action",
          "value": {
            "fallbackText": "--",
            "template": "{{default(source_mavros_basic_motion_status.status.active_action,\"\")}}"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778142604171_9vb89",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "motion phase",
          "layout": {
            "h": 9,
            "w": 12,
            "x": 12,
            "y": 54
          },
          "showAttitude": false,
          "showCompass": false,
          "showValueInside": false,
          "styleRules": [
            {
              "emphasis": "normal",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "ne",
                "path": "status.phase",
                "sourceRef": "source_mavros_basic_motion_status",
                "value": "IDLE"
              }
            }
          ],
          "tip": "mavros_basic_motion action phase",
          "value": {
            "fallbackText": "--",
            "template": "{{source_mavros_basic_motion_status.status.phase}}"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778144300959_21hmx",
          "inlineLabelValue": false,
          "kind": "text",
          "label": "setpoint",
          "layout": {
            "h": 9,
            "w": 20,
            "x": 0,
            "y": 35
          },
          "showAttitude": false,
          "showCompass": false,
          "showValueInside": false,
          "styleRules": [],
          "tip": "setpoint_raw/local",
          "value": {
            "fallbackText": "--",
            "template": "p: ({{default(fixed(source_telemetry_setpoint.data.local.position.x, 1), \"--\")}}, {{default(fixed(source_telemetry_setpoint.data.local.position.y, 1), \"--\")}}, {{default(fixed(source_telemetry_setpoint.data.local.position.z, 1), \"--\")}})     \nv: ({{default(fixed(source_telemetry_setpoint.data.local.velocity.x, 1), \"--\")}}, {{default(fixed(source_telemetry_setpoint.data.local.velocity.y, 1), \"--\")}}, {{default(fixed(source_telemetry_setpoint.data.local.velocity.z, 1), \"--\")}})"
          },
          "valueAlign": "left"
        },
        {
          "backgroundColor": "transparent",
          "compassFrame": "enu",
          "fallbackText": "--",
          "fontSize": 10,
          "id": "widget_1778419421999_7c78h",
          "inlineLabelValue": true,
          "kind": "text",
          "label": "SP SOURCE",
          "layout": {
            "h": 5,
            "w": 24,
            "x": 0,
            "y": 49
          },
          "showAttitude": false,
          "showCompass": false,
          "showValueInside": false,
          "styleRules": [
            {
              "emphasis": "normal",
              "labelColor": "var(--color-status-warning)",
              "textColor": "var(--color-status-warning)",
              "when": {
                "op": "not_exists",
                "path": "snapshot.current_source",
                "sourceRef": "source_mavros_setpoint_mux_status",
                "value": ""
              }
            }
          ],
          "tip": "",
          "value": {
            "fallbackText": "--",
            "template": "{{source_mavros_setpoint_mux_status.snapshot.current_source}}"
          },
          "valueAlign": "left"
        }
      ]
    }
  }
};
