#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_NAME="$(basename "${SCRIPT_DIR}")"
OUTPUT_DIR="${1:-$(dirname "${SCRIPT_DIR}")}"
OUTPUT_DIR="$(mkdir -p "${OUTPUT_DIR}" && cd "${OUTPUT_DIR}" && pwd)"
OUTPUT_PATH="${OUTPUT_DIR}/${PKG_NAME}.zip"
UI_DIR="${SCRIPT_DIR}/ui"
UI_INDEX_PATH="${UI_DIR}/index.html"
PANEL_DIR="${SCRIPT_DIR}/swarm_dashboard"

if [[ ! -f "${UI_INDEX_PATH}" ]]; then
  echo "[pack.sh] ui/index.html not found, building UI from swarm_dashboard ..."

  if [[ ! -d "${PANEL_DIR}" ]]; then
    echo "[pack.sh] missing frontend source directory: ${PANEL_DIR}" >&2
    exit 1
  fi

  if ! command -v pnpm >/dev/null 2>&1; then
    echo "[pack.sh] pnpm is required to build ui automatically" >&2
    exit 1
  fi

  if [[ ! -d "${PANEL_DIR}/node_modules" ]]; then
    echo "[pack.sh] panel dependencies are missing, running pnpm install first ..."
    (
      cd "${PANEL_DIR}"
      pnpm install
    )
  fi

  (
    cd "${PANEL_DIR}"
    pnpm build
  )

  if [[ ! -f "${UI_INDEX_PATH}" ]]; then
    echo "[pack.sh] ui build finished but ${UI_INDEX_PATH} is still missing" >&2
    exit 1
  fi
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required" >&2
  exit 1
fi

python3 - "$SCRIPT_DIR" "$OUTPUT_PATH" <<'PY'
import os
import sys
import zipfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.parent.mkdir(parents=True, exist_ok=True)

ignored_dirs = {
    ".git",
    "swarm_dashboard",
}

try:
    out_rel = out.relative_to(root)
except ValueError:
    out_rel = None

with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for current_root, dirnames, filenames in os.walk(root):
        current_path = Path(current_root)
        dirnames[:] = [d for d in dirnames if d not in ignored_dirs]

        for filename in filenames:
            file_path = current_path / filename
            rel_path = file_path.relative_to(root)

            if rel_path.parts and rel_path.parts[0] in ignored_dirs:
                continue
            if out_rel is not None and rel_path == out_rel:
                continue

            zf.write(file_path, rel_path.as_posix())
PY

echo "Created: ${OUTPUT_PATH}"
