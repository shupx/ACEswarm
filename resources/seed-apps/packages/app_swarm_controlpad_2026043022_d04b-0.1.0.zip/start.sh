#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UI_CONFIG_PATH="${SCRIPT_DIR}/ui/app-config.js"

echo "[start.sh] started at $(date '+%Y-%m-%d %H:%M:%S')"
echo "[start.sh] app: ${AIVUDA_APP_ID:-swarm_controlpad}@${AIVUDA_APP_VERSION:-0.1.0}"

mkdir -p "$(dirname "${UI_CONFIG_PATH}")"

python3 - "${AIVUDA_APP_CONFIG_PATH:-}" "${UI_CONFIG_PATH}" <<'PY'
import json
import sys
from pathlib import Path

import yaml

config_path = Path(sys.argv[1]) if sys.argv[1] else None
ui_config_path = Path(sys.argv[2])

def get_value(data, *keys):
    current = data
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current

def get_dict(data, *keys):
    value = get_value(data, *keys)
    return value if isinstance(value, dict) else None

def get_str(data, *keys):
    value = get_value(data, *keys)
    return value if isinstance(value, str) else None

payload = {
    "zenoh": {
        "proxyPath": "/zenoh_remote_api/ws",
        "websocketLocator": "",
    },
}

if config_path and config_path.is_file():
    with config_path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if not isinstance(data, dict):
        data = {}

    proxy_path = get_str(data, "zenoh", "plugins", "remote_api", "proxy_path")
    if proxy_path and proxy_path.strip():
        payload["zenoh"]["proxyPath"] = proxy_path.strip()

    websocket_locator = get_str(data, "swarm_controlpad", "zenoh", "websocket_locator")
    if websocket_locator is not None:
        payload["zenoh"]["websocketLocator"] = websocket_locator

    settings = get_dict(data, "swarm_controlpad", "controlpad_default_settings")
    if settings is not None:
        payload["layout"] = settings

ui_config_path.write_text(
    "window.__SWARM_CONTROLPAD_CONFIG__ = "
    + json.dumps(payload, ensure_ascii=False, indent=2)
    + ";\n",
    encoding="utf-8",
)
PY

echo "[start.sh] ui config: ${UI_CONFIG_PATH}"
echo "[start.sh] ui config content begin"
sed 's/^/[start.sh] ui config | /' "${UI_CONFIG_PATH}"
echo "[start.sh] ui config content end"
echo "[start.sh] static UI package is ready; no backend service will be started"

exec tail -f /dev/null
